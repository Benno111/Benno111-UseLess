#![allow(dead_code)]

use crate::framebuffer;
use crate::acpi;
use crate::crash_predictor;

use spin::Mutex;
use core::sync::atomic::{AtomicBool, Ordering};
use alloc::format;

mod apps;

/* ============================================================
   CONFIG
============================================================ */

pub const MAX_WINDOWS: usize = 6;
pub const MAX_ICONS: usize = 6;
pub const MAX_USERS: usize = 4;
pub const WORKSPACES: usize = 4;
pub const TASKBAR_H: usize = 22;

pub const TITLEBAR_H: usize = 16;
pub const BTN: usize = 12;
pub const BTN_GAP: usize = 2;
pub const BTN_MARGIN: usize = 4;
pub const RESIZE_BORDER: usize = 6;

pub const MAX_DISPLAYS: usize = 4;

const SNAP_DIST: usize = 14;

/* ============================================================
   DATA TYPES
============================================================ */

#[derive(Clone, Copy)]
pub struct Window {
    pub title: &'static str,
    pub x: usize,
    pub y: usize,
    pub w: usize,
    pub h: usize,
}

type WindowRender = fn(&Window);

/* ============================================================
   CAPABILITY SANDBOX
============================================================ */

bitflags::bitflags! {
    #[derive(Clone, Copy)]
    pub struct Caps: u32 {
        const DRAW  = 1<<0;
        const INPUT = 1<<1;
        const FS    = 1<<2;
        const NET   = 1<<3;
        const POWER = 1<<4;
    }
}

/* ============================================================
   DISPLAY
============================================================ */

#[derive(Clone, Copy)]
pub struct DisplayInfo {
    pub id: usize,
    pub x: usize,
    pub y: usize,
    pub w: usize,
    pub h: usize,
}

impl DisplayInfo {
    pub fn contains(&self, px: usize, py: usize) -> bool {
        px >= self.x && px < self.x + self.w &&
        py >= self.y && py < self.y + self.h
    }
}

/* ============================================================
   THEME
============================================================ */

#[derive(Clone, Copy)]
pub struct Theme {
    pub desktop_bg: (u8,u8,u8),
    pub taskbar_bg: (u8,u8,u8),
    pub window_border: (u8,u8,u8),
    pub window_body: (u8,u8,u8),
    pub title_text: (u8,u8,u8),
    pub button_close: (u8,u8,u8),
    pub button_max: (u8,u8,u8),
    pub button_min: (u8,u8,u8),
    pub accent: (u8,u8,u8),
}

pub const THEME_DAY: Theme = Theme {
    desktop_bg: (18,20,26),
    taskbar_bg: (26,30,38),
    window_border: (50,120,200),
    window_body: (20,20,20),
    title_text: (255,255,255),
    button_close: (180,80,80),
    button_max: (80,180,100),
    button_min: (80,100,180),
    accent: (82,156,255),
};

pub const THEME_NIGHT: Theme = Theme {
    desktop_bg: (8,10,14),
    taskbar_bg: (12,14,18),
    window_border: (38,70,120),
    window_body: (12,12,12),
    title_text: (220,220,220),
    button_close: (140,60,60),
    button_max: (60,130,80),
    button_min: (60,80,130),
    accent: (70,120,200),
};

/* ============================================================
   WINDOW ENTRY
============================================================ */

#[derive(Clone)]
struct WindowEntry {
    window: Window,
    render: WindowRender,
    workspace: usize,
    minimized: bool,
    maximized: bool,
    restore: Option<(usize,usize,usize,usize)>,
    caps: Caps,
    app_id: u32,
}

/* ============================================================
   DESKTOP STATE
============================================================ */

#[derive(Clone, Copy)]
struct DragState {
    active: bool,
    idx: usize,
    offset_x: isize,
    offset_y: isize,
    // resize sides: (l,r,t,b)
    resize: Option<(bool,bool,bool,bool)>,
}

impl DragState {
    const fn new() -> Self {
        Self { active:false, idx:0, offset_x:0, offset_y:0, resize:None }
    }
}

#[derive(Clone, Copy)]
struct DesktopIcon {
    label: &'static str,
    render: WindowRender,
}

#[derive(Clone)]
struct DesktopState {
    windows: [Option<WindowEntry>; MAX_WINDOWS],
    drag: DragState,
    active_workspace: usize,
    icons: [Option<DesktopIcon>; MAX_ICONS],
    overview: bool,
    alt_tab_index: usize,
}

impl DesktopState {
    const fn new() -> Self {
        Self {
            windows: [None; MAX_WINDOWS],
            drag: DragState::new(),
            active_workspace: 0,
            icons: [None; MAX_ICONS],
            overview: false,
            alt_tab_index: 0,
        }
    }
}

/* ============================================================
   USER SLOT
============================================================ */

#[derive(Clone)]
struct UserSlot {
    desktop: DesktopState,
}

impl UserSlot {
    const fn empty() -> Self {
        Self { desktop: DesktopState::new() }
    }
}

/* ============================================================
   WINDOW MANAGER STATE
============================================================ */

struct State {
    mouse: (usize,usize),

    displays: [Option<DisplayInfo>; MAX_DISPLAYS],
    desktop_size: (usize,usize),

    users: [Option<UserSlot>; MAX_USERS],
    active_user: usize,

    theme: Theme,
    night_mode: bool,
}

static STATE: Mutex<State> = Mutex::new(State {
    mouse: (20,20),

    displays: [Some(DisplayInfo{id:0,x:0,y:0,w:640,h:480}),None,None,None],
    desktop_size: (640,480),

    users: [None,None,None,None],
    active_user: 0,

    theme: THEME_DAY,
    night_mode: false,
});

/* ============================================================
   RENDER GUARD
============================================================ */

static RENDERING: AtomicBool = AtomicBool::new(false);

struct RenderGuard;

impl RenderGuard {
    fn new() -> Option<Self> {
        if RENDERING
            .compare_exchange(false,true,Ordering::SeqCst,Ordering::SeqCst)
            .is_err()
        { return None; }
        Some(Self)
    }
}

impl Drop for RenderGuard {
    fn drop(&mut self) {
        RENDERING.store(false, Ordering::SeqCst);
    }
}

/* ============================================================
   HELPERS
============================================================ */

fn clamp(v: isize, min: isize, max: isize) -> isize {
    if v < min { min } else if v > max { max } else { v }
}

fn th() -> Theme {
    let st = STATE.lock();
    if st.night_mode { THEME_NIGHT } else { st.theme }
}

fn active_user_mut(st: &mut State) -> &mut UserSlot {
    if st.users[st.active_user].is_none() {
        st.users[st.active_user] = Some(UserSlot::empty());
    }
    st.users[st.active_user].as_mut().unwrap()
}

fn active_user_ref(st: &State) -> Option<&UserSlot> {
    st.users.get(st.active_user).and_then(|u| u.as_ref())
}

/* ============================================================
   DISPLAY MANAGEMENT
============================================================ */

pub fn set_displays(list: &[DisplayInfo]) {
    let mut st = STATE.lock();

    st.displays = [None; MAX_DISPLAYS];
    let mut max_x = 0usize;
    let mut max_y = 0usize;

    let mut wrote = 0usize;
    for (i,d) in list.iter().copied().take(MAX_DISPLAYS).enumerate() {
        st.displays[i] = Some(DisplayInfo{id:i,..d});
        max_x = max_x.max(d.x + d.w);
        max_y = max_y.max(d.y + d.h);
        wrote += 1;
    }

    if wrote == 0 {
        st.displays[0] = Some(DisplayInfo{id:0,x:0,y:0,w:640,h:480});
        max_x = 640;
        max_y = 480;
    }

    st.desktop_size = (max_x,max_y);
    framebuffer::invalidate();
}

pub fn set_bounds(w: usize, h: usize) {
    set_displays(&[DisplayInfo{id:0,x:0,y:0,w,h}]);
}

/* ============================================================
   INIT
============================================================ */

pub fn init_login_window() {
    // Current tree uses "login" as entry, but the WM is already desktop-first.
    init_desktop();
}

pub fn init_desktop() {
    let mut st = STATE.lock();
    let user = active_user_mut(&mut st);

    user.desktop.icons = [
        Some(DesktopIcon{label:"Console",render:apps::render_console}),
        Some(DesktopIcon{label:"Apps",render:apps::render_apps}),
        Some(DesktopIcon{label:"Logs",render:apps::render_logs}),
        Some(DesktopIcon{label:"Tasks",render:apps::render_task_manager}),
        None,None
    ];

    // seed windows
    register_window_locked(
        &mut user.desktop,
        Window{title:"Console",x:20,y:40,w:320,h:180},
        apps::render_console,
        Caps::DRAW|Caps::INPUT,
        1,
        user.desktop.active_workspace
    );

    framebuffer::invalidate();
}

/* ============================================================
   WINDOW API
============================================================ */

fn register_window_locked(
    desktop: &mut DesktopState,
    win: Window,
    render: WindowRender,
    caps: Caps,
    app_id: u32,
    workspace: usize,
) {
    if let Some(slot) = desktop.windows.iter_mut().find(|s| s.is_none()) {
        *slot = Some(WindowEntry{
            window: win,
            render,
            workspace: workspace.min(WORKSPACES.saturating_sub(1)),
            minimized:false,
            maximized:false,
            restore:None,
            caps,
            app_id,
        });
    }
}

pub fn register_window(win: Window, render: WindowRender, caps: Caps, app_id: u32) {
    let mut st = STATE.lock();
    let user = active_user_mut(&mut st);
    let ws = user.desktop.active_workspace;
    register_window_locked(&mut user.desktop, win, render, caps, app_id, ws);
    framebuffer::invalidate();
}

fn bring_to_front(windows: &mut [Option<WindowEntry>; MAX_WINDOWS], idx: usize) {
    if idx >= MAX_WINDOWS { return; }
    let entry = windows[idx].take();
    if entry.is_none() { return; }

    for i in idx..MAX_WINDOWS-1 {
        windows[i] = windows[i+1].take();
    }
    windows[MAX_WINDOWS-1] = entry;
}

fn window_at(
    windows: &[Option<WindowEntry>; MAX_WINDOWS],
    ws: usize,
    x: usize,
    y: usize,
) -> Option<usize> {
    let mut found = None;
    for (idx, e) in windows.iter().enumerate() {
        if let Some(ent) = e.as_ref() {
            if ent.workspace != ws || ent.minimized { continue; }
            let w = ent.window;
            if x >= w.x && x < w.x + w.w && y >= w.y && y < w.y + w.h {
                found = Some(idx);
            }
        }
    }
    found
}

fn top_window_index(windows: &[Option<WindowEntry>; MAX_WINDOWS], ws: usize) -> Option<usize> {
    for i in (0..MAX_WINDOWS).rev() {
        if let Some(e) = windows[i].as_ref() {
            if e.workspace == ws && !e.minimized {
                return Some(i);
            }
        }
    }
    None
}

/* ============================================================
   BUTTON RECTS
============================================================ */

fn close_rect(w:&Window)->Rect {
    Rect{ x: w.x+w.w-BTN-BTN_MARGIN, y: w.y+2, w: BTN, h: BTN }
}
fn max_rect(w:&Window)->Rect {
    Rect{ x: w.x+w.w-BTN*2-BTN_MARGIN-BTN_GAP, y: w.y+2, w: BTN, h: BTN }
}
fn min_rect(w:&Window)->Rect {
    Rect{ x: w.x+w.w-BTN*3-BTN_MARGIN-BTN_GAP*2, y: w.y+2, w: BTN, h: BTN }
}

#[derive(Clone, Copy)]
struct Rect { x:usize, y:usize, w:usize, h:usize }
impl Rect {
    fn contains(&self, px:usize, py:usize) -> bool {
        px >= self.x && px < self.x + self.w && py >= self.y && py < self.y + self.h
    }
}

/* ============================================================
   RESIZE HIT-TEST
============================================================ */

fn resize_hit(win: &Window, x: usize, y: usize) -> Option<(bool,bool,bool,bool)> {
    if x < win.x || y < win.y || x >= win.x + win.w || y >= win.y + win.h {
        return None;
    }
    let left   = x < win.x + RESIZE_BORDER;
    let right  = x >= win.x + win.w - RESIZE_BORDER;
    let top    = y < win.y + RESIZE_BORDER;
    let bottom = y >= win.y + win.h - RESIZE_BORDER;

    if left || right || top || bottom {
        Some((left,right,top,bottom))
    } else {
        None
    }
}

fn in_title_bar(win: &Window, x: usize, y: usize) -> bool {
    x >= win.x && x < win.x + win.w && y >= win.y && y < win.y + TITLEBAR_H
}

/* ============================================================
   SNAPPING
============================================================ */

fn display_for_point(st: &State, x: usize, y: usize) -> DisplayInfo {
    st.displays.iter().flatten().find(|d| d.contains(x,y)).copied()
        .unwrap_or(DisplayInfo{id:0,x:0,y:0,w:st.desktop_size.0,h:st.desktop_size.1})
}

fn apply_snap(win: &mut Window, disp: DisplayInfo) {
    // left / right / maximize
    let left_edge = disp.x;
    let right_edge = disp.x + disp.w;
    let top_edge = disp.y;
    let bottom_edge = disp.y + disp.h;

    // Maximize if near top
    if win.y <= top_edge + SNAP_DIST {
        win.x = left_edge;
        win.y = top_edge;
        win.w = disp.w;
        win.h = disp.h.saturating_sub(TASKBAR_H);
        return;
    }

    // Left/right half if near edges
    if win.x <= left_edge + SNAP_DIST {
        win.x = left_edge;
        win.y = top_edge;
        win.w = disp.w / 2;
        win.h = disp.h.saturating_sub(TASKBAR_H);
        return;
    }
    if win.x + win.w >= right_edge.saturating_sub(SNAP_DIST) {
        win.x = left_edge + disp.w / 2;
        win.y = top_edge;
        win.w = disp.w - disp.w/2;
        win.h = disp.h.saturating_sub(TASKBAR_H);
        return;
    }

    // keep within bounds
    if win.x + win.w > right_edge { win.x = right_edge.saturating_sub(win.w); }
    if win.y + win.h > bottom_edge.saturating_sub(TASKBAR_H) {
        win.y = bottom_edge.saturating_sub(TASKBAR_H + win.h);
    }
}

/* ============================================================
   INPUT
============================================================ */

pub fn move_mouse(dx: isize, dy: isize) {
    let mut st = STATE.lock();
    let (dw,dh) = st.desktop_size;

    let new_x = clamp(st.mouse.0 as isize + dx, 0, dw.saturating_sub(1) as isize) as usize;
    let new_y = clamp(st.mouse.1 as isize + dy, 0, dh.saturating_sub(1) as isize) as usize;

    st.mouse = (new_x,new_y);

    // handle drag
    let ws = active_user_ref(&st).map(|u| u.desktop.active_workspace).unwrap_or(0);
    let user = active_user_mut(&mut st);

    if user.desktop.drag.active {
        let idx = user.desktop.drag.idx;
        if let Some(ent) = user.desktop.windows.get_mut(idx).and_then(|o| o.as_mut()) {
            if let Some((l,r,t,b)) = user.desktop.drag.resize {
                // resize
                let mut x0 = ent.window.x as isize;
                let mut y0 = ent.window.y as isize;
                let mut w0 = ent.window.w as isize;
                let mut h0 = ent.window.h as isize;

                if l {
                    let nx = new_x as isize;
                    let old_right = x0 + w0;
                    x0 = nx;
                    w0 = old_right - x0;
                }
                if r {
                    w0 = (new_x as isize) - x0;
                }
                if t {
                    let ny = new_y as isize;
                    let old_bot = y0 + h0;
                    y0 = ny;
                    h0 = old_bot - y0;
                }
                if b {
                    h0 = (new_y as isize) - y0;
                }

                // minimums
                let min_w = 120isize;
                let min_h = 60isize;
                if w0 < min_w { w0 = min_w; }
                if h0 < min_h { h0 = min_h; }

                // clamp to desktop bounds
                let max_x = dw as isize;
                let max_y = dh as isize - TASKBAR_H as isize;

                if x0 < 0 { x0 = 0; }
                if y0 < 0 { y0 = 0; }
                if x0 + w0 > max_x { w0 = max_x - x0; }
                if y0 + h0 > max_y { h0 = max_y - y0; }

                ent.window.x = x0 as usize;
                ent.window.y = y0 as usize;
                ent.window.w = w0 as usize;
                ent.window.h = h0 as usize;
            } else {
                // move
                let nx = clamp(new_x as isize + user.desktop.drag.offset_x, 0, (dw.saturating_sub(ent.window.w)) as isize);
                let ny = clamp(new_y as isize + user.desktop.drag.offset_y, 0, (dh.saturating_sub(ent.window.h + TASKBAR_H)) as isize);
                ent.window.x = nx as usize;
                ent.window.y = ny as usize;
            }

            // keep within workspace display bounds (soft clamp)
            if ent.workspace != ws { ent.workspace = ws; }
        }
    }

    framebuffer::invalidate();
}

pub fn mouse_release_left() {
    let mut st = STATE.lock();
    let (mx,my) = st.mouse;

    let user = active_user_mut(&mut st);
    if user.desktop.drag.active {
        // apply snap on drop (only if dragging move; resizing already clamped)
        if user.desktop.drag.resize.is_none() {
            let disp = display_for_point(&st, mx, my);
            if let Some(ent) = user.desktop.windows.get_mut(user.desktop.drag.idx).and_then(|o| o.as_mut()) {
                apply_snap(&mut ent.window, disp);
            }
        }
    }
    user.desktop.drag.active = false;
    user.desktop.drag.resize = None;
    framebuffer::invalidate();
}

pub fn mouse_click_right() {
    // Right click toggles overview for now.
    let mut st = STATE.lock();
    let user = active_user_mut(&mut st);
    user.desktop.overview = !user.desktop.overview;
    framebuffer::invalidate();
}

pub fn mouse_click_left() {
    let (mx,my) = {
        let st = STATE.lock();
        st.mouse
    };

    // Overview click: close overview if clicked empty
    {
        let mut st = STATE.lock();
        let user = active_user_mut(&mut st);
        if user.desktop.overview {
            // If click hits a tile, bring that window front and exit overview
            if let Some(idx) = overview_hit_index(&user.desktop, &st, mx, my) {
                bring_to_front(&mut user.desktop.windows, idx);
                user.desktop.overview = false;
                framebuffer::invalidate();
                return;
            }
            user.desktop.overview = false;
            framebuffer::invalidate();
            return;
        }
    }

    // Taskbar: workspace buttons + minimized windows restore
    if handle_taskbar_click(mx,my) {
        return;
    }

    // Window buttons and drag/resize
    if handle_window_mouse_down(mx,my) {
        return;
    }

    // Desktop icons open windows
    if handle_icon_click(mx,my) {
        return;
    }

    framebuffer::invalidate();
}

pub fn handle_key_input(ch: char) -> bool {
    // Char-based binding layer (your input system currently provides chars).
    // - '\t' cycles windows (Alt-Tab surrogate)
    // - 'o' toggles overview
    // - 'n' toggles night mode
    match ch {
        '\t' => { alt_tab(); true }
        'o' | 'O' => { toggle_overview(); true }
        'n' | 'N' => { toggle_night_mode(); true }
        _ => false
    }
}

pub fn toggle_night_mode() {
    let mut st = STATE.lock();
    st.night_mode = !st.night_mode;
    framebuffer::invalidate();
}

pub fn toggle_overview() {
    let mut st = STATE.lock();
    let user = active_user_mut(&mut st);
    user.desktop.overview = !user.desktop.overview;
    framebuffer::invalidate();
}

pub fn alt_tab() {
    let mut st = STATE.lock();
    let ws = active_user_ref(&st).map(|u| u.desktop.active_workspace).unwrap_or(0);
    let user = active_user_mut(&mut st);

    // choose next visible window in workspace
    for _ in 0..MAX_WINDOWS {
        user.desktop.alt_tab_index = (user.desktop.alt_tab_index + 1) % MAX_WINDOWS;
        let idx = user.desktop.alt_tab_index;
        if let Some(e) = user.desktop.windows.get(idx).and_then(|o| o.as_ref()) {
            if e.workspace == ws && !e.minimized {
                bring_to_front(&mut user.desktop.windows, idx);
                break;
            }
        }
    }
    framebuffer::invalidate();
}

/* ============================================================
   TASKBAR / ICONS CLICK
============================================================ */

fn handle_taskbar_click(x:usize,y:usize)->bool{
    let mut st = STATE.lock();
    let thm = th();
    let user = active_user_mut(&mut st);

    // taskbar region is per display; treat a click on any display taskbar
    for d in st.displays.iter().flatten() {
        let bar_y = d.y + d.h - TASKBAR_H;
        if y < bar_y || y >= bar_y + TASKBAR_H { continue; }

        // workspace buttons
        let mut btn_x = d.x + 6;
        for ws in 0..WORKSPACES {
            let rect = Rect{ x: btn_x, y: bar_y+3, w: 36, h: 16 };
            if rect.contains(x,y) {
                user.desktop.active_workspace = ws;
                user.desktop.drag.active = false;
                user.desktop.drag.resize = None;
                framebuffer::invalidate();
                return true;
            }
            btn_x += 42;
        }

        // window buttons (restore minimized or bring to front)
        let ws = user.desktop.active_workspace;
        for (idx, ent) in user.desktop.windows.iter().enumerate() {
            let Some(e) = ent.as_ref() else { continue; };
            if e.workspace != ws { continue; }
            let rect = Rect{ x: btn_x, y: bar_y+3, w: 90, h: 16 };
            if rect.contains(x,y) {
                let Some(mut_e) = user.desktop.windows[idx].as_mut() else { break; };
                mut_e.minimized = false;
                bring_to_front(&mut user.desktop.windows, idx);
                framebuffer::invalidate();
                return true;
            }
            btn_x += 96;
            if btn_x >= d.x + d.w { break; }
        }

        // clicked taskbar but no button
        let _ = thm;
        return true;
    }

    false
}

fn icon_rect(idx: usize) -> Rect {
    let col = idx % 3;
    let row = idx / 3;
    let x = 16 + col * 80;
    let y = 24 + row * 80;
    Rect{ x, y, w: 48, h: 48 }
}

fn handle_icon_click(x:usize,y:usize)->bool{
    let mut st = STATE.lock();
    let bounds = st.desktop_size;
    let user = active_user_mut(&mut st);
    let mut hit = None;

    for (idx, icon) in user.desktop.icons.iter().enumerate() {
        let Some(ic) = icon.as_ref() else { continue; };
        let r = icon_rect(idx);
        if r.contains(x,y) { hit = Some(*ic); break; }
    }

    let Some(icon) = hit else { return false; };

    // If window exists in workspace, bring to front.
    let ws = user.desktop.active_workspace;
    for (idx, ent) in user.desktop.windows.iter().enumerate() {
        if let Some(e) = ent.as_ref() {
            if e.workspace == ws && e.window.title == icon.label {
                bring_to_front(&mut user.desktop.windows, idx);
                framebuffer::invalidate();
                return true;
            }
        }
    }

    // else open new
    let (dw,dh) = bounds;
    let w = 320usize;
    let h = 180usize;
    let x0 = clamp(x as isize, 0, (dw.saturating_sub(w)) as isize) as usize;
    let y0 = clamp(y as isize, 0, (dh.saturating_sub(h + TASKBAR_H)) as isize) as usize;

    register_window_locked(
        &mut user.desktop,
        Window{ title: icon.label, x: x0, y: y0, w, h },
        icon.render,
        Caps::DRAW|Caps::INPUT,
        100,
        ws
    );
    framebuffer::invalidate();
    true
}

/* ============================================================
   WINDOW MOUSE DOWN + BUTTONS
============================================================ */

fn handle_window_mouse_down(x:usize,y:usize)->bool{
    let mut st = STATE.lock();
    let ws = active_user_ref(&st).map(|u| u.desktop.active_workspace).unwrap_or(0);
    let user = active_user_mut(&mut st);

    let Some(idx) = window_at(&user.desktop.windows, ws, x, y) else { return false; };
    bring_to_front(&mut user.desktop.windows, idx);
    let top = top_window_index(&user.desktop.windows, ws).unwrap_or(idx);

    let Some(ent) = user.desktop.windows.get_mut(top).and_then(|o| o.as_mut()) else { return false; };
    let w = ent.window;

    // buttons
    if close_rect(&w).contains(x,y) {
        user.desktop.windows[top] = None;
        framebuffer::invalidate();
        return true;
    }
    if min_rect(&w).contains(x,y) {
        ent.minimized = true;
        user.desktop.drag.active = false;
        user.desktop.drag.resize = None;
        framebuffer::invalidate();
        return true;
    }
    if max_rect(&w).contains(x,y) {
        toggle_maximize(&mut ent.window, ent);
        framebuffer::invalidate();
        return true;
    }

    // resize border?
    if let Some(sides) = resize_hit(&w, x, y) {
        user.desktop.drag.active = true;
        user.desktop.drag.idx = top;
        user.desktop.drag.resize = Some(sides);
        user.desktop.drag.offset_x = 0;
        user.desktop.drag.offset_y = 0;
        framebuffer::invalidate();
        return true;
    }

    // titlebar drag
    if in_title_bar(&w, x, y) {
        user.desktop.drag.active = true;
        user.desktop.drag.idx = top;
        user.desktop.drag.resize = None;
        user.desktop.drag.offset_x = w.x as isize - x as isize;
        user.desktop.drag.offset_y = w.y as isize - y as isize;
        framebuffer::invalidate();
        return true;
    }

    true
}

fn toggle_maximize(win: &mut Window, ent: &mut WindowEntry) {
    if ent.maximized {
        if let Some((x,y,w,h)) = ent.restore.take() {
            win.x = x; win.y = y; win.w = w; win.h = h;
        }
        ent.maximized = false;
    } else {
        ent.restore = Some((win.x, win.y, win.w, win.h));
        let st = STATE.lock();
        let disp = display_for_point(&st, st.mouse.0, st.mouse.1);
        win.x = disp.x;
        win.y = disp.y;
        win.w = disp.w;
        win.h = disp.h.saturating_sub(TASKBAR_H);
        ent.maximized = true;
    }
}

/* ============================================================
   RENDERING
============================================================ */

pub fn render() {
    let Some(_g) = RenderGuard::new() else { return; };

    if !framebuffer::framebuffer_available() {
        crash_predictor::note_framebuffer_unavailable();
        return;
    }

    let st = STATE.lock();
    let thm = th();
    let mouse = st.mouse;
    let displays = st.displays;
    let ws = active_user_ref(&st).map(|u| u.desktop.active_workspace).unwrap_or(0);
    let overview = active_user_ref(&st).map(|u| u.desktop.overview).unwrap_or(false);
    drop(st);

    framebuffer::invalidate();

    // base desktop (per display)
    for d in displays.iter().flatten() {
        framebuffer::draw_rect(d.x, d.y, d.w, d.h, thm.desktop_bg);
        // taskbar
        let bar_y = d.y + d.h - TASKBAR_H;
        framebuffer::draw_rect(d.x, bar_y, d.w, TASKBAR_H, thm.taskbar_bg);

        // workspaces
        let mut x = d.x + 6;
        for wsi in 0..WORKSPACES {
            let active = wsi == ws;
            let col = if active { thm.accent } else { (60,66,78) };
            framebuffer::draw_rect(x, bar_y + 3, 36, 16, col);
            framebuffer::draw_text(&format!("W{}", wsi+1), x + 8, bar_y + 6);
            x += 42;
        }

        // window tabs
        let st2 = STATE.lock();
        let user = active_user_ref(&st2);
        if let Some(u) = user {
            let mut tx = x;
            for ent in u.desktop.windows.iter().flatten() {
                if ent.workspace != ws { continue; }
                if tx + 90 >= d.x + d.w { break; }
                framebuffer::draw_rect(tx, bar_y + 3, 90, 16, (45,48,56));
                framebuffer::draw_text(ent.window.title, tx + 6, bar_y + 6);
                tx += 96;
            }
        }
        drop(st2);
    }

    // desktop icons (single desktop coordinate system)
    render_icons();

    // windows
    render_windows(ws, thm);

    if overview {
        render_overview(ws);
    }

    // cursor
    framebuffer::draw_rect(mouse.0, mouse.1, 6, 6, (255,255,255));

    framebuffer::render_frame();
}

fn render_icons() {
    let mut st = STATE.lock();
    let user = active_user_mut(&mut st);
    for (idx, icon) in user.desktop.icons.iter().enumerate() {
        let Some(ic) = icon.as_ref() else { continue; };
        let r = icon_rect(idx);
        framebuffer::draw_rect(r.x, r.y, r.w, r.h, (40,44,54));
        framebuffer::draw_text(ic.label, r.x + 6, r.y + r.h + 4);
    }
}

fn render_windows(ws: usize, thm: Theme) {
    let mut st = STATE.lock();
    let user = active_user_mut(&mut st);

    for ent in user.desktop.windows.iter().flatten() {
        if ent.minimized || ent.workspace != ws { continue; }

        let w = ent.window;

        framebuffer::draw_rect(w.x, w.y, w.w, w.h, thm.window_border);
        framebuffer::draw_rect(w.x+2, w.y+TITLEBAR_H, w.w-4, w.h-TITLEBAR_H-2, thm.window_body);
        framebuffer::draw_text(w.title, w.x+6, w.y+2);

        // buttons
        let c = close_rect(&w);
        let m = max_rect(&w);
        let n = min_rect(&w);

        framebuffer::draw_rect(c.x, c.y, c.w, c.h, thm.button_close);
        framebuffer::draw_text("X", c.x+3, c.y+1);

        framebuffer::draw_rect(m.x, m.y, m.w, m.h, thm.button_max);
        framebuffer::draw_text("□", m.x+2, m.y+1);

        framebuffer::draw_rect(n.x, n.y, n.w, n.h, thm.button_min);
        framebuffer::draw_text("_", n.x+3, n.y+3);

        // app render
        (ent.render)(&w);
    }
}

/* ============================================================
   OVERVIEW
============================================================ */

fn overview_layout(st: &State) -> (usize,usize,usize,usize) {
    let (dw,dh) = st.desktop_size;
    let w = dw/2 - 20;
    let h = dh/2 - 20;
    (10,10,w,h)
}

fn overview_hit_index(desktop: &DesktopState, st: &State, x:usize, y:usize) -> Option<usize> {
    let (ox,oy,w,h) = overview_layout(st);
    let tile_w = w;
    let tile_h = h;
    for (i, ent) in desktop.windows.iter().enumerate() {
        let Some(e) = ent.as_ref() else { continue; };
        // 2x2 grid
        let col = i % 2;
        let row = i / 2;
        let tx = ox + col * (tile_w + 10);
        let ty = oy + row * (tile_h + 10);
        let r = Rect{ x:tx, y:ty, w:tile_w, h:tile_h };
        if r.contains(x,y) { return Some(i); }
    }
    None
}

fn render_overview(ws: usize) {
    let st = STATE.lock();
    let (dw,dh) = st.desktop_size;
    drop(st);

    framebuffer::draw_rect(0,0,dw,dh,(0,0,0));
    framebuffer::draw_text("Overview", 12, 12);

    let mut st = STATE.lock();
    let user = active_user_mut(&mut st);
    let windows = user.desktop.windows.clone();
    drop(st);

    let (ox,oy,w,h) = {
        let st = STATE.lock();
        overview_layout(&st)
    };

    let mut i = 0usize;
    for e in windows.iter().flatten() {
        if e.workspace != ws { continue; }
        let col = i % 2;
        let row = i / 2;
        let x = ox + col*(w+10);
        let y = oy + row*(h+10);
        framebuffer::draw_rect(x,y,w,h,(40,60,90));
        framebuffer::draw_text(e.window.title, x+6, y+6);
        i += 1;
    }
}

/* ============================================================
   POWER
============================================================ */

pub fn reboot(){ acpi::reboot(); }
pub fn shutdown(){ acpi::power_off(); }

/* ============================================================
   STATUS
============================================================ */

pub fn desktop_active() -> bool { true }
